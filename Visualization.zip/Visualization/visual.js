//lIKAGE ANOTHER JS FILE
import { reportMonths, years, monthOption, yearOption } from "./dataFix.js";

//DEFAULT CHART STYLE
Chart.defaults.font.size = 20;
Chart.register(ChartDataLabels);

//GETTING HTML TAG
const ctx1 = document.getElementById("canvas1");
const ctx2 = document.getElementById("canvas2");
const ctx3 = document.getElementById("canvas3");
const ctx4 = document.getElementById("canvas4");
const ctx5 = document.getElementById("canvas5");

export const townshipOption = document.getElementById("selectedTownship");
const searchButton = document.getElementById("searchBtn");

let spsTownshipLable = [];
let package1 = [];
let package2 = [];
let package3 = [];
let package4 = [];
let package5 = [];
let package6 = [];
let package7 = [];
let package8 = [];
let enrollPateint_male = [];
let enrollPateint_female = [];
let totalPackages = [];
let allPackages = [];
let startDate = document.getElementById("start-date");
let endDate = document.getElementById("end-date");

function getAllData(selectedTownshipValue) {
  //Destroy if exit
  if (ctx1) {
    var ctx1Chart = Chart.getChart(ctx1);
    if (ctx1Chart) {
      ctx1Chart.destroy();
    }
    // ctx1.remove();
  }
  if (ctx2) {
    var ctx2Chart = Chart.getChart(ctx2);
    if (ctx2Chart) {
      ctx2Chart.destroy();
    }
    // ctx2.remove();
  }
  if (ctx3) {
    var ctx3Chart = Chart.getChart(ctx3);
    if (ctx3Chart) {
      ctx3Chart.destroy();
    }
    // ctx3.remove();
  }
  if (ctx4) {
    var ctx4Chart = Chart.getChart(ctx4);
    if (ctx4Chart) {
      ctx4Chart.destroy();
    }
    // ctx4.remove();
  }
  if (ctx5) {
    var ctx5Chart = Chart.getChart(ctx5);
    if (ctx5Chart) {
      ctx5Chart.destroy();
    }
    // ctx5.remove();
  }
  // console.log("call getAllData");
  // PACKAGE API REPORT
  let url1 = "https://mdrsps-api.unionais.org/api/v1/power-bi-report-viz?";
  let url2 = "https://mdrsps-api.unionais.org/api/v1/patient-report?";
  let url3 = "https://mdrsps-api.unionais.org/api/v1/chartjs-townships?";

  if (selectedTownshipValue) {
    //Hmue Thet Paing API
    url1 += `township_id=${selectedTownshipValue}`;
    url2 += `township_id=${selectedTownshipValue}`;

    //Kaung San API
    url3 += `township_id=${selectedTownshipValue}`;
  }
  fetch(url1)
    .then((res) => res.json())
    .then((result) => {
      const reportData = result.data;
      console.log(typeof reportData);
      reportData.forEach((d) => {
        spsTownshipLable.push(d.township);
        package1.push(d.result.packageSupportForConsultation);
        package2.push(d.result.packageSupportForInvestigation);
        package3.push(d.result.packageSupportForMedication);
        package4.push(d.result.packageSupportForHospitalization);
        package5.push(d.result.kindAward);
        package6.push(d.result.packageSupportForHousing);
        package7.push(d.result.packageSupportForEducation);
        package8.push(d.result.packageSupportForInjection);
        totalPackages.push(d.result.total);
        enrollPateint_male.push(d.result.enrolledDRPatient_male);
        enrollPateint_female.push(d.result.enrolledDRPatient_female);
        allPackages.push(d.result.packageSupportForConsultation);
        allPackages.push(d.result.packageSupportForInvestigation);
        allPackages.push(d.result.packageSupportForMedication);
        allPackages.push(d.result.packageSupportForHospitalization);
        allPackages.push(d.result.kindAward);
        allPackages.push(d.result.packageSupportForHousing);
        allPackages.push(d.result.packageSupportForEducation);
        allPackages.push(d.result.packageSupportForInjection);
      });

      const chart1 = new Chart(ctx1, {
        type: "bar", //config
        data: {
          labels: spsTownshipLable, // Typo: should be townshipLabel
          datasets: [
            {
              label: "All Packages",
              data: totalPackages,
              borderColor: "black",
              backgroundColor: "#A52A2A",
              borderWidth: 2,
            },
          ],
        },
        options: {
          // indexAxis: "y",
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            title: {
              display: true,
              text: "Total Supported Number of All Packages ",
            },
            datalabels: {
              data: totalPackages,
              display: true,
              color: "blue",
              anchor: "end",
              align: "top",
              offset: 10,
              font: {
                size: 20,
              },
            },
          },
        },
      });

      const chart2 = new Chart(ctx2, {
        type: "bar",
        data: {
          labels: spsTownshipLable, // Typo: should be townshipLabel
          datasets: [
            {
              label: "Female",
              data: enrollPateint_female,
              backgroundColor: "green",
            },
            {
              label: "Male",
              data: enrollPateint_male,
              backgroundColor: "#00008B",
            },
          ],
        },
        options: {
          indexAxis: "x",
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            title: {
              display: true,
              text: "Total Patients by Each Township ",
            },
            datalabels: {
              data: totalPackages,
              display: true,
              color: "blue",
              anchor: "end",
              align: "top",
              offset: 10,
              font: {
                size: 20,
              },
            },
          },
        },
      });

      function sumArray(array) {
        let sum = 0;
        for (let i = 0; i < array.length; i++) {
          sum += array[i];
        }
        return sum;
      }

      let package1Count = sumArray(package1);
      let package2Count = sumArray(package2);
      let package3Count = sumArray(package3);
      let package4Count = sumArray(package4);
      let package5Count = sumArray(package5);
      let package6Count = sumArray(package6);
      let package7Count = sumArray(package7);
      let package8Count = sumArray(package8);
      let packagesCountArray = [
        package1Count,
        package2Count,
        package3Count,
        package4Count,
        package5Count,
        package6Count,
        package7Count,
        package8Count,
      ];

      var chart3 = new Chart(ctx3, {
        type: "doughnut",
        data: {
          labels: [
            "Package1",
            "Package2",
            "Package3",
            "Package4",
            "Package5",
            "Package6",
            "Package7",
            "Package8",
          ], // Typo: should be townshipLabel
          datasets: [
            {
              label: "All Packages",
              data: packagesCountArray,
              backgroundColor: [
                "#000000",
                "#0000FF",
                "#FFC0CB",
                "#FF0000",
                "#808080",
                "#FFA500",
                "#00FF00",
                "#FF00FF",
              ],
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            title: {
              display: true,
              text: "All Packages ",
            },
            datalabels: {
              data: totalPackages,
              display: true,
              color: "white",
              font: {
                size: 25,
              },
            },
          },
        },
      });
      const chart4 = new Chart(ctx4, {
        type: "bar",
        data: {
          labels: ["All Pakcages"],
          datasets: [
            {
              label: "Package1",
              data: [package1Count],
              backgroundColor: "green",
            },
            {
              label: "Package2",
              data: [package2Count],
              backgroundColor: "red",
            },
            {
              label: "Package3",
              data: [package3Count],
              backgroundColor: "black",
            },
            {
              label: "Package4",
              data: [package4Count],
              backgroundColor: "blue",
            },
            {
              label: "Package5",
              data: [package5Count],
              backgroundColor: "pink",
            },
            {
              label: "Package6",
              data: [package6Count],
              backgroundColor: "red",
            },
            {
              label: "Package7",
              data: [package7Count],
              backgroundColor: "gray",
            },
            {
              label: "Package8",
              data: [package8Count],
              backgroundColor: "orange",
            },
          ],
        },
        options: {
          indexAxis: "x",
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            title: {
              display: true,
              text: "By Each Packages ",
            },
            datalabels: {
              display: true,
              color: "blue",
              anchor: "end",
              align: "top",
              offset: 10,
              font: {
                size: 20,
              },
            },
          },
        },
      });
    });

  //OUTCOME DATA API REPORT
  let getOutcomeName = [];
  let getOutcomeData = [];
  fetch(url2)
    .then((result) => result.json())
    .then((getData) => {
      const outcomeData = getData.data.outcomes;
      outcomeData.forEach((da) => {
        getOutcomeName.push(da.title);
        getOutcomeData.push(da.value);
      });
      const chart5 = new Chart(ctx5, {
        type: "doughnut",
        data: {
          labels: getOutcomeName,
          datasets: [
            {
              //label: getOutcomeName,
              data: getOutcomeData,
              backgroundColor: [
                "#000000",
                "#0000FF",
                "#FFC0CB",
                "#FF0000",
                "#808080",
                "#FFA500",
                "#00FF00",
                "#FF00FF",
              ],
            },
          ],
        },
        options: {
          legend: {
            display: false,
          },
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            title: {
              display: true,
              text: "Outcomes Report",
            },
            datalabels: {
              data: getOutcomeData,
              display: true,
              color: "white",
              font: {
                size: 25,
              },
            },
          },
        },
      });
    });

  //Township Drop Downlist Filter
  fetch(url3)
    .then((result) => result.json())
    .then((getData) => {
      const townshipData = getData;
      //to extract and construct an array of object with value and label
      const township = townshipData.data?.map((element) => ({
        value: element.id,
        label: element.name,
      }));
      township.forEach((tws) => {
        const option = document.createElement("option");
        option.value = tws.value;
        option.text = tws.label;
        townshipOption.appendChild(option);
      });
    });
}
getAllData();

//Search Button Clicking
searchButton.addEventListener("click", function () {
  let selectedMonthValue = monthOption.value;
  let selectedYearValue = yearOption.value;
  let selectedTownshipValue = townshipOption.value;
  let selectedStartDate = startDate.value;
  let selectedEndDate = endDate.value;

  getAllData(selectedTownshipValue);
});

//Clear Button
let clearBtn = document.getElementById("clearBtn");
clearBtn.addEventListener("click", function () {
  monthOption.value = "";
  yearOption.value = "";
  townshipOption.value = "";
  startDate.value = "";
  endDate.value = "";
});
